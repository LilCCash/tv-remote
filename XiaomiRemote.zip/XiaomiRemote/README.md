# Xiaomi Remote (iOS)

Telecomando per **Xiaomi Android TV / Google TV** sulla stessa rete Wi-Fi. SwiftUI, nessuna dipendenza esterna,
nessun account, nessun server, nessuna pubblicità. iOS 16 o successivo, solo iPhone.

> **Stato onesto:** il codice è stato scritto e rivisto ma **non è stato compilato né provato su una TV reale**
> (l'ambiente di sviluppo non aveva Swift/Xcode). Al primo build potrebbero comparire piccoli errori da correggere
> in Xcode. I test unitari sono inclusi ma **non sono stati eseguiti**. Vedi «Cosa è verificato» più sotto.

## Protocollo scelto

**Android TV Remote Protocol v2** (lo stesso dell'app Google TV): non richiede ADB né modalità sviluppatore.
La TV deve avere il servizio *Android TV Remote Service*, preinstallato sulla maggior parte delle Android TV.

| Fase | Dettaglio |
|---|---|
| Scoperta | mDNS/Bonjour `_androidtvremote2._tcp` (+ inserimento manuale dell'IP) |
| Associazione | TLS sulla porta **6467**, messaggi protobuf "polo"; la TV mostra un codice a 6 caratteri; segreto = SHA-256(modulo/esponente client, modulo/esponente TV, ultimi 2 byte del codice) |
| Controllo | TLS sulla porta **6466** con certificato client; `RemoteKeyInject` (codici tasto Android), `RemoteAppLinkLaunchRequest` (link di app), ping/handshake |

Fonti consultate: `remotemessage.proto` e documentazione del pairing della libreria `androidtvremote2`
(tronikos), schemi `pairingmessage.proto` dei client di riferimento (louis49/androidtv-remote).

**Non inclusi, e perché:** ADB (richiede debug di rete attivato dall'utente, non standard), HDMI-CEC (nessun percorso
dall'iPhone senza hardware esterno), Wake-on-LAN (serve il MAC e la TV deve supportarlo).

## Installazione sul tuo iPhone

Serve un **Mac con Xcode 15+** (non si può compilare un'app iOS senza). Un ID Apple gratuito basta, ma l'app
installata così scade dopo 7 giorni (si reinstalla da Xcode); con l'Apple Developer Program (99 €/anno) dura un anno.

**Opzione A – XcodeGen**
1. `brew install xcodegen`, poi nella cartella del progetto `xcodegen generate` e apri `XiaomiRemote.xcodeproj`.
2. In `project.yml` cambia `bundleIdPrefix` / `PRODUCT_BUNDLE_IDENTIFIER` con un identificatore tuo.

**Opzione B – a mano**
1. Xcode › File › New › Project › iOS App (SwiftUI, Swift), nome `XiaomiRemote`, deployment target **iOS 16.0**.
2. Elimina `ContentView.swift` e il file `@main` generato; trascina dentro la cartella `Sources` (gruppi + target).
3. Target › Info: aggiungi `NSLocalNetworkUsageDescription` (testo a piacere) e `NSBonjourServices` = array con `_androidtvremote2._tcp`.
4. (Facoltativo) aggiungi un target *Unit Testing Bundle* e trascina `Tests`.

**Firma e installazione**
1. Target › Signing & Capabilities › scegli il tuo *Team* (accedi con l'ID Apple in Xcode › Settings › Accounts).
2. Sull'iPhone: Impostazioni › Privacy e sicurezza › **Modalità sviluppatore** (poi riavvio).
3. Collega l'iPhone con il cavo, selezionalo come destinazione e premi ▶︎. Alla prima installazione:
   Impostazioni › Generali › VPN e gestione dispositivo › **Autorizza** il tuo profilo.
4. Dopo la prima volta puoi usare «Connect via network» (Window › Devices and Simulators) per non usare il cavo.

## Primo utilizzo
1. Accendi la TV, iPhone sullo stesso Wi-Fi. Consenti l'accesso alla **Rete locale** quando iOS lo chiede.
2. Scegli la TV (o inserisci l'IP: Impostazioni TV › Rete). Sulla TV compare un codice a 6 caratteri: scrivilo nell'app.
3. L'app si collega e salva la TV. Se la TV è spenta o la rete cade, riprova da sola con attesa crescente.

## Come sono mappati i controlli
Frecce/OK/Indietro/Home/Menu/Recenti/Impostazioni TV/Volume ±/Muto/Play-Pausa/Avanti/Indietro veloce = codici tasto Android
(`KEYCODE_*`) inviati con `RemoteKeyInject`. **Menu** e **Opzioni** sono lo stesso tasto (`KEYCODE_MENU`): Android TV non ha
due tasti distinti. **Ingressi**: selettore (`KEYCODE_TV_INPUT`) + frecce/OK, più HDMI 1-3 diretti (`KEYCODE_TV_INPUT_HDMI_*`,
non garantiti su tutte le TV). **Tastiera**: invia i tasti lettera/cifra/punteggiatura (maiuscole e accenti semplificati, emoji no).
**Touchpad**: gesti → frecce e OK (non esiste un puntatore). **App**: invia un link alla TV (`RemoteAppLinkLaunchRequest`).

## Cosa è verificato e cosa no
- ✅ Porte, schemi dei messaggi, codici tasto e formula del segreto: confrontati con la documentazione/le librerie di riferimento.
- ✅ Byte dei messaggi principali calcolati a mano e usati nei test (`ProtocolTests`).
- ❌ Compilazione, esecuzione dei test e prova su una Xiaomi reale: **non fatte**.
- ⚠️ Punti più a rischio al primo test: creazione dell'identità TLS nel Keychain (`CertificateManager`), valore `featureFlags = 622`
  nell'handshake, permesso Rete locale.
- ⚠️ Dipendono da modello/app: HDMI diretti, Recenti, comandi multimediali, link delle app (YouTube/Netflix/Prime/Disney+ da verificare),
  stato acceso/standby e volume (arrivano solo se la TV li invia).
- ❌ Non disponibili: accensione da TV spenta, elenco ingressi/app installate, titolo in riproduzione, controllo di soundbar.
- La digitazione usa i tasti Android perché lo schema `RemoteImeBatchEdit` delle fonti consultate era incoerente tra versioni.

## Sicurezza e privacy
Solo rete locale. Salvati sul dispositivo: elenco TV e preferenze (UserDefaults), identità TLS dell'app e impronta SHA-256 del certificato
della TV (Keychain, solo questo dispositivo, nessun backup). Il certificato della TV è «bloccato» alla prima connessione: se cambia
(TV ripristinata) l'app lo segnala e chiede di ripetere l'associazione. Nessun PIN viene salvato.

## Architettura (`Sources/`)
`Core/` protocollo (`Protobuf`, `Messages`, `TLSChannel`, `PairingSession`, `RemoteSession`, `Certificates`, `Errors` = ErrorHandler) ·
`Services/` (`TVDiscoveryService`, `TVConnectionManager`, `RemoteCommandService`, `KeyboardInputService`, `DeviceStorage`, `PairingFlow`) ·
`UI/` (SwiftUI) · `App/`. Una sola sessione alla volta; i comandi con la TV offline vengono scartati (mai accodati) per non rieseguirli in ritardo.
**Modalità test** (Impostazioni): i comandi non vengono inviati, solo registrati.

## Test (`Tests/`, ⌘U)
Codifica/decodifica protocollo, segreto di pairing, flusso di pairing con TV simulata (ordine messaggi, rifiuto, codice errato,
timeout), riconnessione, TV non disponibile, permesso di rete negato, ordine dei comandi, TV offline, modalità test, tastiera.
